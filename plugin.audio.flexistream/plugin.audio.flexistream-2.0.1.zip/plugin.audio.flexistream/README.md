# FlexiStream
FlexiStream makes managing and playing audio streams on Kodi easy.

It reads a yml configuration file to generate a list of selectable streams:
    
    streams:
      Idobi Radio:
        url: http://idobiradio.idobi.com/;stream.mp3
        fanart_image: https://idobi.com/radio/live/tmp/images/idobi.jpg

    
## Settings
Set the used configuration file in the plugin settings.