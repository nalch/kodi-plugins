# FlexiStream
FlexiStream makes managing and playing video streams on Kodi easy.

It reads a yml configuration file to generate a list of selectable streams:
    
    streams:
      Idobi Video:
        url: http://idobivideo.idobi.com/;stream.mp3
        fanart_image: https://idobi.com/video/live/tmp/images/idobi.jpg

    
## Settings
Set the used configuration file in the plugin settings.